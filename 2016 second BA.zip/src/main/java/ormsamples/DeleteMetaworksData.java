/**
 * Licensee: kosta9
 * License Type: Purchased
 */
package ormsamples;

import org.orm.*;
public class DeleteMetaworksData {
	public void deleteTestData() throws PersistentException {
		PersistentTransaction t = oai.auto_insurance.model.MetaworksPersistentManager.instance().getSession().beginTransaction();
		try {
			oai.auto_insurance.model.Customer loaiauto_insurancemodelCustomer= (oai.auto_insurance.model.Customer)oai.auto_insurance.model.MetaworksPersistentManager.instance().getSession().createQuery("From oai.auto_insurance.model.Customer").setMaxResults(1).uniqueResult();
			oai.auto_insurance.model.MetaworksPersistentManager.instance().getSession().delete(loaiauto_insurancemodelCustomer);
			
			oai.auto_insurance.model.Order loaiauto_insurancemodelOrder= (oai.auto_insurance.model.Order)oai.auto_insurance.model.MetaworksPersistentManager.instance().getSession().createQuery("From oai.auto_insurance.model.Order").setMaxResults(1).uniqueResult();
			oai.auto_insurance.model.MetaworksPersistentManager.instance().getSession().delete(loaiauto_insurancemodelOrder);
			
			t.commit();
		}
		catch (Exception e) {
			t.rollback();
		}
	}
	
	public static void main(String[] args) {
		try {
			DeleteMetaworksData deleteMetaworksData = new DeleteMetaworksData();
			try {
				deleteMetaworksData.deleteTestData();
			}
			finally {
				oai.auto_insurance.model.MetaworksPersistentManager.instance().disposePersistentManager();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
