/**
 * Licensee: kosta9
 * License Type: Purchased
 */
package ormsamples;

import org.orm.*;
public class CreateMetaworksDatabaseSchema {
	public static void main(String[] args) {
		try {
			ORMDatabaseInitiator.createSchema(oai.auto_insurance.model.MetaworksPersistentManager.instance());
			oai.auto_insurance.model.MetaworksPersistentManager.instance().disposePersistentManager();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
