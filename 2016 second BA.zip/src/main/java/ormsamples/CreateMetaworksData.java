/**
 * Licensee: kosta9
 * License Type: Purchased
 */
package ormsamples;

import org.orm.*;
public class CreateMetaworksData {
	public void createTestData() throws PersistentException {
		PersistentTransaction t = oai.auto_insurance.model.MetaworksPersistentManager.instance().getSession().beginTransaction();
		try {
			oai.auto_insurance.model.Customer loaiauto_insurancemodelCustomer = new oai.auto_insurance.model.Customer();			// TODO Initialize the properties of the persistent object here, the following properties must be initialized before saving : order
			oai.auto_insurance.model.MetaworksPersistentManager.instance().getSession().save(loaiauto_insurancemodelCustomer);
			
			oai.auto_insurance.model.Order loaiauto_insurancemodelOrder = new oai.auto_insurance.model.Order();			// TODO Initialize the properties of the persistent object here, the following properties must be initialized before saving : qty, customer
			oai.auto_insurance.model.MetaworksPersistentManager.instance().getSession().save(loaiauto_insurancemodelOrder);
			
			t.commit();
		}
		catch (Exception e) {
			t.rollback();
		}
		
	}
	
	public static void main(String[] args) {
		try {
			CreateMetaworksData createMetaworksData = new CreateMetaworksData();
			try {
				createMetaworksData.createTestData();
			}
			finally {
				oai.auto_insurance.model.MetaworksPersistentManager.instance().disposePersistentManager();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
