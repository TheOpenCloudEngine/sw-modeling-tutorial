/**
 * Licensee: kosta9
 * License Type: Purchased
 */
package ormsamples;

import org.orm.*;
public class RetrieveAndUpdateMetaworksData {
	public void retrieveAndUpdateTestData() throws PersistentException {
		PersistentTransaction t = oai.auto_insurance.model.MetaworksPersistentManager.instance().getSession().beginTransaction();
		try {
			oai.auto_insurance.model.Customer loaiauto_insurancemodelCustomer= (oai.auto_insurance.model.Customer)oai.auto_insurance.model.MetaworksPersistentManager.instance().getSession().createQuery("From oai.auto_insurance.model.Customer").setMaxResults(1).uniqueResult();
			// Update the properties of the persistent object
			oai.auto_insurance.model.MetaworksPersistentManager.instance().getSession().update(loaiauto_insurancemodelCustomer);
			
			oai.auto_insurance.model.Order loaiauto_insurancemodelOrder= (oai.auto_insurance.model.Order)oai.auto_insurance.model.MetaworksPersistentManager.instance().getSession().createQuery("From oai.auto_insurance.model.Order").setMaxResults(1).uniqueResult();
			// Update the properties of the persistent object
			oai.auto_insurance.model.MetaworksPersistentManager.instance().getSession().update(loaiauto_insurancemodelOrder);
			
			t.commit();
		}
		catch (Exception e) {
			t.rollback();
		}
	}
	
	public static void main(String[] args) {
		try {
			RetrieveAndUpdateMetaworksData retrieveAndUpdateMetaworksData = new RetrieveAndUpdateMetaworksData();
			try {
				retrieveAndUpdateMetaworksData.retrieveAndUpdateTestData();
			}
			finally {
				oai.auto_insurance.model.MetaworksPersistentManager.instance().disposePersistentManager();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
