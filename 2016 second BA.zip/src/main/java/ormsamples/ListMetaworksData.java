/**
 * Licensee: kosta9
 * License Type: Purchased
 */
package ormsamples;

import org.orm.*;
public class ListMetaworksData {
	private static final int ROW_COUNT = 100;
	
	public void listTestData() throws PersistentException {
		System.out.println("Listing Customer...");
		java.util.List lCustomerList = oai.auto_insurance.model.MetaworksPersistentManager.instance().getSession().createQuery("From oai.auto_insurance.model.Customer").setMaxResults(ROW_COUNT).list();
		oai.auto_insurance.model.Customer[] loaiauto_insurancemodelCustomers = (oai.auto_insurance.model.Customer[]) lCustomerList.toArray(new oai.auto_insurance.model.Customer[lCustomerList.size()]);
		int length = Math.min(loaiauto_insurancemodelCustomers.length, ROW_COUNT);
		for (int i = 0; i < length; i++) {
			System.out.println(loaiauto_insurancemodelCustomers[i]);
		}
		System.out.println(length + " record(s) retrieved.");
		
		System.out.println("Listing Order...");
		java.util.List lOrderList = oai.auto_insurance.model.MetaworksPersistentManager.instance().getSession().createQuery("From oai.auto_insurance.model.Order").setMaxResults(ROW_COUNT).list();
		oai.auto_insurance.model.Order[] loaiauto_insurancemodelOrders = (oai.auto_insurance.model.Order[]) lOrderList.toArray(new oai.auto_insurance.model.Order[lOrderList.size()]);
		length = Math.min(loaiauto_insurancemodelOrders.length, ROW_COUNT);
		for (int i = 0; i < length; i++) {
			System.out.println(loaiauto_insurancemodelOrders[i]);
		}
		System.out.println(length + " record(s) retrieved.");
		
	}
	
	public static void main(String[] args) {
		try {
			ListMetaworksData listMetaworksData = new ListMetaworksData();
			try {
				listMetaworksData.listTestData();
			}
			finally {
				oai.auto_insurance.model.MetaworksPersistentManager.instance().disposePersistentManager();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
