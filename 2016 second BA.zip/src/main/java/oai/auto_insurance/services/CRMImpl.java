package oai.auto_insurance.services;

import oai.auto_insurance.model.Customer;
import org.orm.PersistentException;
import org.springframework.jdbc.support.CustomSQLErrorCodesTranslation;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import javax.jws.WebService;
import javax.ws.rs.GET;

@Controller
//@WebService(endpointInterface = "oai.auto_insurance.services.CRM")
public class CRMImpl implements CRM {
    @Override
    public void addCustomer(Customer customer) {
        try {
            oai.auto_insurance.model.MetaworksPersistentManager.instance().getSession().save(customer);
        } catch (PersistentException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    @GET
    public Customer getCustomer(String id) {

        Customer customer = new Customer();
        customer.setLastName("jjj");


        return customer;  //To change body of implemented methods use File | Settings | File Templates.
    }
}