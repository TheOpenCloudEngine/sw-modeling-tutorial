package oai.auto_insurance.services;

import oai.auto_insurance.model.*;

@javax.jws.WebService
public interface CRM {

	/**
	 *
	 * @param customer
	 */
	void addCustomer(Customer customer);
    Customer getCustomer(String id);

}