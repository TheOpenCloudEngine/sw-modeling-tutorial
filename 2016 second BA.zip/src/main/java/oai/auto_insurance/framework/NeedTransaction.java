package oai.auto_insurance.framework;

/**
 * Created with IntelliJ IDEA.
 * User: kosta-2
 * Date: 16. 7. 7
 * Time: 오전 10:09
 * To change this template use File | Settings | File Templates.
 */
public @interface NeedTransaction {
}
