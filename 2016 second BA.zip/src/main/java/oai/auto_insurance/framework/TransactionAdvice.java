package oai.auto_insurance.framework;

import oai.auto_insurance.model.MetaworksPersistentManager;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.orm.PersistentException;
import org.springframework.stereotype.Component;

/**
 * Created with IntelliJ IDEA.
 * User: kosta-2
 * Date: 16. 7. 7
 * Time: 오전 10:10
 * To change this template use File | Settings | File Templates.
 */
@Aspect
@Component
public class TransactionAdvice {

    @Before("@annotation(oai.auto_insurance.framework.NeedTransaction)")
    public void initiateTransaction() throws PersistentException {
        System.out.println("start tx");
        MetaworksPersistentManager.instance().getSession().beginTransaction();
    }

    @AfterReturning("@annotation(oai.auto_insurance.framework.NeedTransaction)")
    public void commitTransaction() throws Exception {
        System.out.println("commit");
        MetaworksPersistentManager.instance().getSession().getTransaction().commit();
    }

    @AfterThrowing("@annotation(oai.auto_insurance.framework.NeedTransaction)")
    public void rollbackTransaction() throws Exception {
        System.out.println("rollback");
        MetaworksPersistentManager.instance().getSession().getTransaction().rollback();
    }
}
