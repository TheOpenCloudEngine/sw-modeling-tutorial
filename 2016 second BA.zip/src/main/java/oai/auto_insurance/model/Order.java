/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: kosta9
 * License Type: Purchased
 */
package oai.auto_insurance.model;

import java.io.Serializable;
import javax.persistence.*;
@Entity
@org.hibernate.annotations.Proxy(lazy=false)
@Table(name="`Order`")
public class Order implements Serializable {
	public Order() {
	}
	
	@Column(name="OrderNo", nullable=false, length=11)	
	@Id	
	@GeneratedValue(generator="OAI_AUTO_INSURANCE_MODEL_ORDER_ORDERNO_GENERATOR")	
	@org.hibernate.annotations.GenericGenerator(name="OAI_AUTO_INSURANCE_MODEL_ORDER_ORDERNO_GENERATOR", strategy="native")	
	private int orderNo;
	
	@OneToOne(targetEntity=oai.auto_insurance.model.Customer.class, fetch=FetchType.LAZY)	
	@org.hibernate.annotations.Cascade({org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.LOCK})	
	@JoinColumns({ @JoinColumn(name="CustomerID", referencedColumnName="ID", nullable=false) })	
	private oai.auto_insurance.model.Customer customer;
	
	@Column(name="Qty", nullable=false, length=11)	
	private int qty;
	
	@Column(name="ItemId", nullable=true, length=255)	
	private String itemId;
	
	private void setOrderNo(int value) {
		this.orderNo = value;
	}
	
	public int getOrderNo() {
		return orderNo;
	}
	
	public int getORMID() {
		return getOrderNo();
	}
	
	public void setQty(int value) {
		this.qty = value;
	}
	
	public int getQty() {
		return qty;
	}
	
	public void setItemId(String value) {
		this.itemId = value;
	}
	
	public String getItemId() {
		return itemId;
	}
	
	public void setCustomer(oai.auto_insurance.model.Customer value) {
		this.customer = value;
	}
	
	public oai.auto_insurance.model.Customer getCustomer() {
		return customer;
	}
	
	public String toString() {
		return String.valueOf(getOrderNo());
	}
	
}
