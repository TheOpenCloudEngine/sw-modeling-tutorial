package oai.auto_insurance.controller;

import oai.auto_insurance.framework.NeedTransaction;
import oai.auto_insurance.model.*;
import oai.auto_insurance.services.CRM;
import org.metaworks.annotation.ServiceMethod;
import org.orm.PersistentException;
import org.orm.PersistentTransaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class NameAndAddressTab {

	Customer model;

	public Customer getModel() {
		return this.model;
	}

	public void setModel(Customer model) {
        
        if(model == null) throw new IllegalArgumentException();
        
		this.model = model;
	}

    @Autowired
    CRM crm;

    @ServiceMethod(callByContent=true)
	@NeedTransaction
	public VehiclesTab next() throws PersistentException, PersistentException {
        crm.addCustomer(getModel());

		return new VehiclesTab();
	}

	public NameAndAddressTab() {
		setModel(new Customer());
	}

}