package oai.auto_insurance.controller;

import oai.auto_insurance.model.*;
import org.metaworks.annotation.ServiceMethod;

public class VehiclesTab {

	Order model;

	public Order getModel() {
		return this.model;
	}

	public void setModel(Order model) {
		this.model = model;
	}

	public void next() {
		// TODO - implement VehiclesTab.next
		throw new UnsupportedOperationException();
	}

    @ServiceMethod(callByContent = true)
	public NameAndAddressTab previous() {
		// TODO - implement VehiclesTab.previous
		return new NameAndAddressTab();
	}

	public VehiclesTab() {
		// TODO - implement VehiclesTab.VehiclesTab
		setModel(new Order());
	}

}