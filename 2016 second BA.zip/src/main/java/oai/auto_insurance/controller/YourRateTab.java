package oai.auto_insurance.controller;

public class YourRateTab {

	public void previous() {
		// TODO - implement YourRateTab.previous
		throw new UnsupportedOperationException();
	}

	public YourRateTab() {
		// TODO - implement YourRateTab.YourRateTab
		throw new UnsupportedOperationException();
	}
}