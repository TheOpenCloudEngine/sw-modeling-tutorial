package webservice;

import javax.jws.WebService;

import org.orm.PersistentException;
import org.uengine.autoinsurance.*;

@WebService
public interface CRM {

	/**
	 * 
	 * @param parameter
	 */
	void addCustomer(Costomer parameter) throws PersistentException;

	Costomer getCustomer();

	/**
	 * 
	 * @param parameter
	 */
	void addCustomer(Costomer parameter) throws org.orm.PersistentException;

	Costomer getCustomer();

}