package webservice;

import javax.jws.WebService;

import org.framework.NeedTransaction;
import org.orm.PersistentException;
import org.springframework.stereotype.Component;
import org.uengine.autoinsurance.*;

@WebService(endpointInterface="webservice.CRM")
@Component
public class CRMImpl implements CRM {

    @TenantScope
    static public String logoURL = "abc.gif";

    /**
	 * 이 메서드는 고객을 디비에 추가합니다. 그렇습니다.
	 * @param customer
	 */
	@Override
	@NeedTransaction
    public void addCustomer(Costomer customer) throws PersistentException {
       System.out.println("addCustomer");

        AutoinsurancePersistentManager.instance().getSession().save(customer);

    }

    @Override
    public Costomer getCustomer() {
        System.out.println("getCustomer");

        return null;
    }

	/**
	 * 이 메서드는 고객을 디비에 추가합니다. 그렇습니다.
	 * @param customer
	 */
	@Override()
	@NeedTransaction()
	public void addCustomer(Costomer customer) throws org.orm.PersistentException {
		// TODO - implement CRMImpl.addCustomer
		throw new UnsupportedOperationException();
	}
}