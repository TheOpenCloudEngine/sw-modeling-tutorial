public class Capability {
}