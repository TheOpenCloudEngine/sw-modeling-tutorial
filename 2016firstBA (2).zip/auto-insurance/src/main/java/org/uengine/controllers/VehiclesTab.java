package org.uengine.controllers;

import org.uengine.autoinsurance.*;

public class VehiclesTab {

	Order model;
        public Order getModel() {
            return this.model;
        }    
        public void setModel(Order model) {
            this.model = model;
        }

    @org.metaworks.annotation.ServiceMethod(callByContent=true)
	public NameAndAddressTab previous() {
		return new NameAndAddressTab();
	}

	public VehiclesTab() {
		setModel(new Order());
	}


}