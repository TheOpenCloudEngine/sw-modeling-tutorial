package org.uengine.controllers;

import org.framework.NeedTransaction;
import org.metaworks.annotation.Face;
import org.metaworks.annotation.Hidden;
import org.metaworks.annotation.NonEditable;
import org.orm.PersistentException;
import org.orm.PersistentTransaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.uengine.autoinsurance.*;
import webservice.CRM;

@Face(displayName = "고객 기본 정보 입력 단계")
@Component
public class NameAndAddressTab {

	Costomer model;
        public Costomer getModel() {
            return this.model;
        }
        public void setModel(Costomer model) {
            this.model = model;
        }


    String disclaimer;
    @NonEditable
        public String getDisclaimer() {
            return disclaimer;
        }
        public void setDisclaimer(String disclaimer) {
            this.disclaimer = disclaimer;
        }


    @Autowired
    CRM crm;

    @org.metaworks.annotation.ServiceMethod(callByContent=true)
    @Face(displayName="견적을 요청합니다")
	public VehiclesTab startMyQuote() throws PersistentException {

        System.out.println("CRM object is " + crm);

        crm.addCustomer(getModel());

        return new VehiclesTab();
	}

	public NameAndAddressTab() {
		setModel(new Customer());
        setDisclaimer("개인정보동의수락에 관한..........");
	}

}

















