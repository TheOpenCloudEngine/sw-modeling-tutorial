/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: 
 * License Type: Evaluation
 */
package org.uengine.autoinsurance;

import org.metaworks.annotation.Face;
import org.orm.PersistentException;
import org.orm.PersistentTransaction;

import java.io.Serializable;
import javax.persistence.*;
@Entity
@org.hibernate.annotations.Proxy(lazy=false)
@Table(name="Customer")
@Face(displayName = "고객 정보를 입력하세요")
public class Customer implements Serializable {
	public Customer() {
	}
	
	@Column(name="ID", nullable=false, length=10)	
	@Id	
	@GeneratedValue(generator="ORG_UENGINE_AUTOINSURANCE_CUSTOMER_ID_GENERATOR")	
	@org.hibernate.annotations.GenericGenerator(name="ORG_UENGINE_AUTOINSURANCE_CUSTOMER_ID_GENERATOR", strategy="native")	
	private int ID;
	
	@Column(name="FirstName", nullable=true, length=255)
	private String firstName;
	
	@Column(name="LastName", nullable=true, length=255)	
	String lastName;
	
	@OneToMany(targetEntity=org.uengine.autoinsurance.Order.class)	
	@org.hibernate.annotations.Cascade({org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.LOCK})	
	@JoinColumns({ @JoinColumn(name="CustomerID", nullable=false) })	
	@org.hibernate.annotations.IndexColumn(name="CustomerIndex")	
	@org.hibernate.annotations.LazyCollection(org.hibernate.annotations.LazyCollectionOption.TRUE)	
	private java.util.List orders = new java.util.ArrayList();
	
	private void setID(int value) {
		this.ID = value;
	}
	
	public int getID() {
		return ID;
	}
	
	public int getORMID() {
		return getID();
	}
	
	public void setFirstName(String value) {
		this.firstName = value;
	}

    @Face(displayName="이름")
	public String getFirstName() {
		return firstName;
	}
	
	public void setLastName(String value) {
		this.lastName = value;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setOrders(java.util.List value) {
		this.orders = value;
	}
	
	public java.util.List getOrders() {
		return orders;
	}
	
	
	public String toString() {
		return String.valueOf(getID());
	}


}
