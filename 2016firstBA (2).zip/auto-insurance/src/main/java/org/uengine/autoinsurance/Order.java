/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: 
 * License Type: Evaluation
 */
package org.uengine.autoinsurance;

import java.io.Serializable;
import javax.persistence.*;
@Entity
@org.hibernate.annotations.Proxy(lazy=false)
@Table(name="`Order`")
public class Order implements Serializable {
	public Order() {
	}
	
	@Column(name="ID", nullable=false, length=10)	
	@Id	
	@GeneratedValue(generator="ORG_UENGINE_AUTOINSURANCE_ORDER_ID_GENERATOR")	
	@org.hibernate.annotations.GenericGenerator(name="ORG_UENGINE_AUTOINSURANCE_ORDER_ID_GENERATOR", strategy="native")	
	private int ID;
	
	@ManyToOne(targetEntity=org.uengine.autoinsurance.Customer.class, fetch=FetchType.LAZY)	
	@org.hibernate.annotations.Cascade({org.hibernate.annotations.CascadeType.LOCK})	
	@JoinColumns({ @JoinColumn(name="CustomerID", referencedColumnName="ID", nullable=false, insertable=false, updatable=false) })	
	private org.uengine.autoinsurance.Customer customer;
	
	@Column(name="ItemId", nullable=true, length=255)	
	private String itemId;
	
	@Column(name="Quantity", nullable=false, length=10)	
	private int quantity;
	
	private void setID(int value) {
		this.ID = value;
	}
	
	public int getID() {
		return ID;
	}
	
	public int getORMID() {
		return getID();
	}
	
	public void setItemId(String value) {
		this.itemId = value;
	}
	
	public String getItemId() {
		return itemId;
	}
	
	public void setQuantity(int value) {
		this.quantity = value;
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	public void setCustomer(org.uengine.autoinsurance.Customer value) {
		this.customer = value;
	}
	
	public org.uengine.autoinsurance.Customer getCustomer() {
		return customer;
	}
	
	public String toString() {
		return String.valueOf(getID());
	}
	
}
