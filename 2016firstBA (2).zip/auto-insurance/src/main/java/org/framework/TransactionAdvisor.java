package org.framework;

import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.orm.PersistentException;
import org.orm.PersistentTransaction;
import org.springframework.stereotype.Component;
import org.uengine.autoinsurance.AutoinsurancePersistentManager;

@Aspect
@Component
public class TransactionAdvisor {

    @Before("@annotation(org.framework.NeedTransaction)")
    public void initiateTransaction() throws PersistentException {
        System.out.println("start tx");
       AutoinsurancePersistentManager.instance().getSession().beginTransaction();

    }

    @AfterReturning("@annotation(org.framework.NeedTransaction)")
    public void commitTransaction() throws Exception {
        System.out.println("commit");
        AutoinsurancePersistentManager.instance().getSession().getTransaction().commit();
    }

    @AfterThrowing("@annotation(org.framework.NeedTransaction)")
    public void rollbackTransaction() throws Exception {
        System.out.println("rollback");
        AutoinsurancePersistentManager.instance().getSession().getTransaction().rollback();
    }
}