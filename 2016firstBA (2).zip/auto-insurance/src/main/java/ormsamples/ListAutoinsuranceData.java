/**
 * Licensee: 
 * License Type: Evaluation
 */
package ormsamples;

import org.orm.*;
public class ListAutoinsuranceData {
	private static final int ROW_COUNT = 100;
	
	public void listTestData() throws PersistentException {
		System.out.println("Listing Customer...");
		java.util.List lCustomerList = org.uengine.autoinsurance.AutoinsurancePersistentManager.instance().getSession().createQuery("From org.uengine.autoinsurance.Customer").setMaxResults(ROW_COUNT).list();
		org.uengine.autoinsurance.Customer[] lorguengineautoinsuranceCustomers = (org.uengine.autoinsurance.Customer[]) lCustomerList.toArray(new org.uengine.autoinsurance.Customer[lCustomerList.size()]);
		int length = Math.min(lorguengineautoinsuranceCustomers.length, ROW_COUNT);
		for (int i = 0; i < length; i++) {
			System.out.println(lorguengineautoinsuranceCustomers[i]);
		}
		System.out.println(length + " record(s) retrieved.");
		
		System.out.println("Listing Order...");
		java.util.List lOrderList = org.uengine.autoinsurance.AutoinsurancePersistentManager.instance().getSession().createQuery("From org.uengine.autoinsurance.Order").setMaxResults(ROW_COUNT).list();
		org.uengine.autoinsurance.Order[] lorguengineautoinsuranceOrders = (org.uengine.autoinsurance.Order[]) lOrderList.toArray(new org.uengine.autoinsurance.Order[lOrderList.size()]);
		length = Math.min(lorguengineautoinsuranceOrders.length, ROW_COUNT);
		for (int i = 0; i < length; i++) {
			System.out.println(lorguengineautoinsuranceOrders[i]);
		}
		System.out.println(length + " record(s) retrieved.");
		
	}
	
	public static void main(String[] args) {
		try {
			ListAutoinsuranceData listAutoinsuranceData = new ListAutoinsuranceData();
			try {
				listAutoinsuranceData.listTestData();
			}
			finally {
				org.uengine.autoinsurance.AutoinsurancePersistentManager.instance().disposePersistentManager();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
