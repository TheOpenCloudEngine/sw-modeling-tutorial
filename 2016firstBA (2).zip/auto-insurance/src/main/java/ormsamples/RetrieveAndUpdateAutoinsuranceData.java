/**
 * Licensee: 
 * License Type: Evaluation
 */
package ormsamples;

import org.orm.*;
public class RetrieveAndUpdateAutoinsuranceData {
	public void retrieveAndUpdateTestData() throws PersistentException {
		PersistentTransaction t = org.uengine.autoinsurance.AutoinsurancePersistentManager.instance().getSession().beginTransaction();
		try {
			org.uengine.autoinsurance.Customer lorguengineautoinsuranceCustomer= (org.uengine.autoinsurance.Customer)org.uengine.autoinsurance.AutoinsurancePersistentManager.instance().getSession().createQuery("From org.uengine.autoinsurance.Customer").setMaxResults(1).uniqueResult();
			// Update the properties of the persistent object
			org.uengine.autoinsurance.AutoinsurancePersistentManager.instance().getSession().update(lorguengineautoinsuranceCustomer);
			
			org.uengine.autoinsurance.Order lorguengineautoinsuranceOrder= (org.uengine.autoinsurance.Order)org.uengine.autoinsurance.AutoinsurancePersistentManager.instance().getSession().createQuery("From org.uengine.autoinsurance.Order").setMaxResults(1).uniqueResult();
			// Update the properties of the persistent object
			org.uengine.autoinsurance.AutoinsurancePersistentManager.instance().getSession().update(lorguengineautoinsuranceOrder);
			
			t.commit();
		}
		catch (Exception e) {
			t.rollback();
		}
	}
	
	public static void main(String[] args) {
		try {
			RetrieveAndUpdateAutoinsuranceData retrieveAndUpdateAutoinsuranceData = new RetrieveAndUpdateAutoinsuranceData();
			try {
				retrieveAndUpdateAutoinsuranceData.retrieveAndUpdateTestData();
			}
			finally {
				org.uengine.autoinsurance.AutoinsurancePersistentManager.instance().disposePersistentManager();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
