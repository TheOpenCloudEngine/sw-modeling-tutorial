/**
 * Licensee: 
 * License Type: Evaluation
 */
package ormsamples;

import org.orm.*;
import org.uengine.autoinsurance.AutoinsurancePersistentManager;
import org.uengine.autoinsurance.Customer;
import org.uengine.autoinsurance.Order;

public class CreateAutoinsuranceData {
	public void saveCustomer() throws PersistentException {
		PersistentTransaction t = AutoinsurancePersistentManager.instance().getSession().beginTransaction();
		try {
			Customer customer = new Customer();

            customer.setFirstName("jjy");
            customer.setLastName("jang");

			AutoinsurancePersistentManager.instance().getSession().save(customer);
			
			t.commit();
		}
		catch (Exception e) {

			t.rollback();
            throw e;
		}
		
	}
	
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			CreateAutoinsuranceData createAutoinsuranceData = new CreateAutoinsuranceData();
			try {
				createAutoinsuranceData.saveCustomer();
			}
			finally {
				AutoinsurancePersistentManager.instance().disposePersistentManager();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
